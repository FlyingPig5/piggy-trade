package com.piggytrade.piggytrade.protocol

import java.math.BigInteger

object ProtocolConfig {
    /**
     * Override shift logic for the free/personal version.
     * Always returns 0.
     */
    fun getNodeConfigP2(n: BigInteger): BigInteger {
        return BigInteger.ZERO
    }
}
